using UnityEngine;
using NEXUS.Core;

namespace NEXUS.Player
{
    /// <summary>
    /// One tick of player intent. The motor only ever consumes this struct, never raw input, so in Phase 8
    /// the same command can be sent to the server and replayed for prediction/reconciliation.
    /// </summary>
    public struct MoveCommand
    {
        public Vector2 Move;       // x = strafe, y = forward (camera relative)
        public float Yaw;          // camera yaw in degrees
        public bool Sprint;        // held
        public bool Jump;          // pressed this tick
        public bool CrouchToggle;  // pressed this tick (crouch toggle / slide trigger)
        public bool Aiming;        // held
    }

    /// <summary>
    /// CharacterController-based movement: run, sprint, jump (coyote time + buffer), crouch, slide.
    /// Prone, vault, climb, mantle and swim arrive in a later phase.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    [DisallowMultipleComponent]
    public class PlayerMotor : MonoBehaviour
    {
        [Header("Speeds (m/s)")]
        [SerializeField] float aimWalkSpeed = 3f;
        [SerializeField] float runSpeed = 5.5f;
        [SerializeField] float sprintSpeed = 8f;
        [SerializeField] float crouchSpeed = 2.5f;

        [Header("Acceleration (m/s^2)")]
        [SerializeField] float groundAcceleration = 45f;
        [SerializeField] float airAcceleration = 6f;

        [Header("Jump / Gravity")]
        [SerializeField] float jumpHeight = 1.2f;
        [SerializeField] float gravity = -22f;
        [SerializeField] float coyoteTime = 0.12f;
        [SerializeField] float jumpBufferTime = 0.12f;
        [SerializeField] float groundStickForce = 6f;
        [SerializeField] float maxFallSpeed = 60f;

        [Header("Slide")]
        [SerializeField] float slideSpeed = 10f;
        [SerializeField] float slideDuration = 0.85f;
        [SerializeField] float slideCooldown = 0.6f;
        [SerializeField] float slideHeight = 1.0f;

        [Header("Body")]
        [SerializeField] float standingHeight = 1.8f;
        [SerializeField] float crouchHeight = 1.1f;
        [SerializeField] float heightChangeSpeed = 6f;
        [SerializeField] float turnSpeed = 720f;
        [SerializeField] LayerMask obstacleMask = ~0;
        [Tooltip("Optional primitive capsule (2m tall at scale 1) that is squashed to match the body height.")]
        [SerializeField] Transform visualRoot;

        [Header("Landing")]
        [SerializeField] float minAirTimeForLanding = 0.2f;
        [SerializeField] float minImpactSpeedForLanding = 6f;

        CharacterController cc;
        Vector3 horizontalVelocity;
        float verticalVelocity;
        float airTime;
        float timeSinceGrounded;
        float jumpBuffer;
        float slideTimer;
        float slideCooldownTimer;
        Vector3 slideDirection;
        Vector3 visualBaseScale = Vector3.one;

        public bool IsGrounded { get; private set; }
        public bool IsSprinting { get; private set; }
        public bool IsCrouching { get; private set; }
        public bool IsSliding { get; private set; }
        public float CurrentHeight { get; private set; }
        public float HorizontalSpeed => horizontalVelocity.magnitude;
        public float VerticalVelocity => verticalVelocity;

        void Awake()
        {
            cc = GetComponent<CharacterController>();
            CurrentHeight = standingHeight;
            if (visualRoot != null) visualBaseScale = visualRoot.localScale;
            ApplyHeight();
        }

        /// <summary>Advance the character by one tick. Call once per Update (or per network tick).</summary>
        public void Simulate(in MoveCommand cmd, float dt)
        {
            if (dt <= 0f) return;

            UpdateGrounded(dt);

            Vector2 moveIn = Vector2.ClampMagnitude(cmd.Move, 1f);
            bool hasInput = moveIn.sqrMagnitude > 0.01f;
            Vector3 wishDir = Quaternion.Euler(0f, cmd.Yaw, 0f) * new Vector3(moveIn.x, 0f, moveIn.y);

            IsSprinting = cmd.Sprint && hasInput && moveIn.y > -0.1f
                          && !IsCrouching && !IsSliding && !cmd.Aiming;

            if (slideCooldownTimer > 0f) slideCooldownTimer -= dt;
            if (cmd.CrouchToggle) HandleCrouchInput(wishDir);

            // Jump buffering + coyote time
            jumpBuffer = cmd.Jump ? jumpBufferTime : jumpBuffer - dt;
            if (jumpBuffer > 0f && timeSinceGrounded <= coyoteTime) TryJump();

            // Horizontal motion
            if (IsSliding)
            {
                slideTimer += dt;
                float t = Mathf.Clamp01(slideTimer / slideDuration);
                float speed = Mathf.Lerp(slideSpeed, crouchSpeed, t * t);
                horizontalVelocity = slideDirection * speed;
                if (t >= 1f) EndSlide();
            }
            else
            {
                float targetSpeed = IsCrouching ? crouchSpeed
                                  : IsSprinting ? sprintSpeed
                                  : cmd.Aiming ? aimWalkSpeed
                                  : runSpeed;
                Vector3 targetVel = wishDir * targetSpeed;
                float accel = IsGrounded ? groundAcceleration : airAcceleration;
                horizontalVelocity = Vector3.MoveTowards(horizontalVelocity, targetVel, accel * dt);
            }

            // Vertical motion
            if (IsGrounded && verticalVelocity <= 0f) verticalVelocity = -groundStickForce;
            verticalVelocity = Mathf.Max(verticalVelocity + gravity * dt, -maxFallSpeed);

            // Apply
            CollisionFlags flags = cc.Move((horizontalVelocity + Vector3.up * verticalVelocity) * dt);
            if (IsSliding && (flags & CollisionFlags.Sides) != 0) EndSlide(); // slid into a wall

            UpdateFacing(cmd, dt);
            UpdateHeight(dt);
        }

        // ----- Ground / jump -----

        void UpdateGrounded(float dt)
        {
            bool wasGrounded = IsGrounded;
            IsGrounded = cc.isGrounded;

            if (IsGrounded)
            {
                if (!wasGrounded && airTime >= minAirTimeForLanding && -verticalVelocity >= minImpactSpeedForLanding)
                    GameEvents.RaisePlayerLanded(-verticalVelocity);
                timeSinceGrounded = 0f;
                airTime = 0f;
            }
            else
            {
                timeSinceGrounded += dt;
                airTime += dt;
            }
        }

        void TryJump()
        {
            // Must be able to stand up first if crouched/sliding.
            if (IsCrouching || IsSliding)
            {
                if (!CanStand()) return;
                if (IsSliding) EndSlide();
                SetCrouch(false);
            }

            verticalVelocity = Mathf.Sqrt(2f * -gravity * jumpHeight);
            jumpBuffer = 0f;
            timeSinceGrounded = coyoteTime + 1f; // consume coyote window (no double jump)
            IsGrounded = false;
            GameEvents.RaisePlayerJumped();
        }

        // ----- Crouch / slide -----

        void HandleCrouchInput(Vector3 wishDir)
        {
            if (IsSliding) { EndSlide(); return; } // slide ends into a crouch

            if (IsSprinting && IsGrounded && slideCooldownTimer <= 0f)
            {
                StartSlide(wishDir);
                return;
            }

            if (IsCrouching) { if (CanStand()) SetCrouch(false); }
            else SetCrouch(true);
        }

        void StartSlide(Vector3 wishDir)
        {
            Vector3 dir = horizontalVelocity.sqrMagnitude > 1f ? horizontalVelocity : wishDir;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.01f) return;

            slideDirection = dir.normalized;
            slideTimer = 0f;
            IsSliding = true;
            IsSprinting = false;
            SetCrouch(true);
            GameEvents.RaisePlayerSlideChanged(true);
        }

        void EndSlide()
        {
            if (!IsSliding) return;
            IsSliding = false;
            slideCooldownTimer = slideCooldown;
            horizontalVelocity = slideDirection * crouchSpeed; // hand off smoothly to crouch-walk
            GameEvents.RaisePlayerSlideChanged(false);
        }

        void SetCrouch(bool crouch)
        {
            if (IsCrouching == crouch) return;
            IsCrouching = crouch;
            GameEvents.RaisePlayerCrouchChanged(crouch);
        }

        /// <summary>Head-clearance test so the player cannot stand up inside a low ceiling.</summary>
        bool CanStand()
        {
            float need = standingHeight - cc.height;
            if (need <= 0.01f) return true;
            float r = cc.radius * 0.95f;
            Vector3 origin = transform.position + Vector3.up * (cc.height - cc.radius);
            return !Physics.SphereCast(origin, r, Vector3.up, out _, need + 0.05f,
                                       obstacleMask, QueryTriggerInteraction.Ignore);
        }

        // ----- Facing / body -----

        void UpdateFacing(in MoveCommand cmd, float dt)
        {
            Vector3 face = Vector3.zero;
            if (IsSliding) face = slideDirection;
            else if (cmd.Aiming) face = Quaternion.Euler(0f, cmd.Yaw, 0f) * Vector3.forward;
            else if (horizontalVelocity.sqrMagnitude > 0.25f) face = horizontalVelocity;

            face.y = 0f;
            if (face.sqrMagnitude < 0.0001f) return;
            Quaternion target = Quaternion.LookRotation(face.normalized, Vector3.up);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, target, turnSpeed * dt);
        }

        void UpdateHeight(float dt)
        {
            float target = IsSliding ? slideHeight : IsCrouching ? crouchHeight : standingHeight;
            CurrentHeight = Mathf.MoveTowards(CurrentHeight, target, heightChangeSpeed * dt);
            ApplyHeight();
        }

        void ApplyHeight()
        {
            cc.height = CurrentHeight;
            cc.center = new Vector3(0f, CurrentHeight * 0.5f, 0f); // feet stay on the pivot

            if (visualRoot != null)
            {
                visualRoot.localPosition = new Vector3(0f, CurrentHeight * 0.5f, 0f);
                visualRoot.localScale = new Vector3(visualBaseScale.x, CurrentHeight * 0.5f, visualBaseScale.z);
            }
        }
    }
}
