using UnityEngine;
using UnityEngine.InputSystem;

namespace NEXUS.Player
{
    /// <summary>
    /// Over-the-shoulder third-person camera: orbit look, ADS zoom, shoulder switch, sprint/slide FOV,
    /// wall collision, plus AddRecoil/AddShake hooks for the weapon system (Phase 2).
    /// Put this on the Camera object and assign the Player root as Target.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    [DisallowMultipleComponent]
    public class ThirdPersonCamera : MonoBehaviour
    {
        [SerializeField] Transform target;

        [Header("Orbit")]
        [SerializeField] float pitchMin = -35f;
        [SerializeField] float pitchMax = 65f;

        [Header("Framing")]
        [SerializeField] float shoulderOffset = 0.65f;
        [SerializeField] float hipDistance = 3.6f;
        [SerializeField] float aimDistance = 2.1f;
        [SerializeField] float pivotHeightFactor = 0.88f;
        [SerializeField] float aimTransitionTime = 0.15f;

        [Header("FOV")]
        [SerializeField] float hipFov = 70f;
        [SerializeField] float aimFov = 55f;
        [SerializeField] float sprintFov = 78f;
        [SerializeField] float slideFov = 82f;
        [SerializeField] float fovSmoothTime = 0.12f;

        [Header("Collision")]
        [SerializeField] float collisionRadius = 0.25f;
        [SerializeField] float minDistance = 0.3f;
        [SerializeField] LayerMask collisionMask = ~0;

        [Header("Recoil / Shake")]
        [SerializeField] float recoilRecovery = 8f;
        [SerializeField] float shakeDecayPerSecond = 3f;
        [SerializeField] float shakeScale = 0.05f;

        [Header("Cursor")]
        [SerializeField] bool lockCursor = true;

        Camera cam;
        PlayerInputReader input;
        PlayerMotor motor;

        float yaw, pitch;
        float recoilPitch, recoilYaw;
        float shakeIntensity;
        float aimBlend;
        float shoulderSide = 1f;    // +1 right, -1 left
        float shoulderCurrent;
        float currentDistance;
        float currentPivotHeight;
        float fovVelocity;
        readonly RaycastHit[] hits = new RaycastHit[8];

        /// <summary>Camera yaw in degrees (without recoil) — the movement/aim reference direction.</summary>
        public float Yaw => yaw;
        public float Pitch => pitch;

        void Awake() => cam = GetComponent<Camera>();

        void OnEnable()
        {
            BindTarget();
            if (lockCursor) SetCursor(true);
        }

        void BindTarget()
        {
            if (target == null) return;
            input = target.GetComponentInParent<PlayerInputReader>();
            motor = target.GetComponentInParent<PlayerMotor>();
            yaw = target.eulerAngles.y;
            pitch = 15f;
            shoulderCurrent = shoulderSide * shoulderOffset;
            currentDistance = hipDistance;
            currentPivotHeight = (motor != null ? motor.CurrentHeight : 1.8f) * pivotHeightFactor;
            cam.fieldOfView = hipFov;
        }

        /// <summary>Assign a new target at runtime (e.g. spectating a teammate).</summary>
        public void SetTarget(Transform newTarget)
        {
            target = newTarget;
            BindTarget();
        }

        /// <summary>Kick the view up/sideways (degrees). Recovers automatically.</summary>
        public void AddRecoil(float pitchUp, float yawRight)
        {
            recoilPitch -= pitchUp;
            recoilYaw += yawRight;
        }

        /// <summary>Screen shake; intensity ~0.1 (light) to 1 (explosion). Decays automatically.</summary>
        public void AddShake(float intensity) => shakeIntensity = Mathf.Max(shakeIntensity, intensity);

        void Update()
        {
            if (target == null) return;
            float dt = Time.deltaTime;

            HandleCursor();

            if (input != null)
            {
                if (!lockCursor || Cursor.lockState == CursorLockMode.Locked)
                {
                    Vector2 look = input.ReadLook(dt);
                    yaw += look.x;
                    pitch = Mathf.Clamp(pitch - look.y, pitchMin, pitchMax);
                }
                if (input.SwitchShoulderPressed) shoulderSide = -shoulderSide;
            }

            float k = 1f - Mathf.Exp(-recoilRecovery * dt);
            recoilPitch = Mathf.Lerp(recoilPitch, 0f, k);
            recoilYaw = Mathf.Lerp(recoilYaw, 0f, k);
            shakeIntensity = Mathf.MoveTowards(shakeIntensity, 0f, shakeDecayPerSecond * dt);
        }

        void LateUpdate()
        {
            if (target == null) return;
            float dt = Time.deltaTime;

            bool aiming = input != null && input.AimHeld;
            aimBlend = Mathf.MoveTowards(aimBlend, aiming ? 1f : 0f, dt / Mathf.Max(0.01f, aimTransitionTime));
            float eased = Mathf.SmoothStep(0f, 1f, aimBlend);

            shoulderCurrent = Mathf.Lerp(shoulderCurrent, shoulderSide * shoulderOffset, 1f - Mathf.Exp(-10f * dt));

            float bodyHeight = motor != null ? motor.CurrentHeight : 1.8f;
            currentPivotHeight = Mathf.Lerp(currentPivotHeight, bodyHeight * pivotHeightFactor, 1f - Mathf.Exp(-12f * dt));

            Quaternion rot = Quaternion.Euler(pitch + recoilPitch, yaw + recoilYaw, 0f);
            Vector3 pivot = target.position + Vector3.up * currentPivotHeight;
            Vector3 origin = pivot + rot * Vector3.right * shoulderCurrent;
            Vector3 back = rot * Vector3.back;

            float preferred = Mathf.Lerp(hipDistance, aimDistance, eased);
            float allowed = ComputeAllowedDistance(origin, back, preferred);

            // Snap in when blocked, ease back out when clear.
            if (allowed < currentDistance) currentDistance = allowed;
            else currentDistance = Mathf.Lerp(currentDistance, allowed, 1f - Mathf.Exp(-6f * dt));

            Vector3 position = origin + back * currentDistance;
            if (shakeIntensity > 0f) position += Random.insideUnitSphere * (shakeIntensity * shakeScale);

            transform.SetPositionAndRotation(position, rot);

            float targetFov = aiming ? aimFov
                            : (motor != null && motor.IsSliding) ? slideFov
                            : (motor != null && motor.IsSprinting) ? sprintFov
                            : hipFov;
            cam.fieldOfView = Mathf.SmoothDamp(cam.fieldOfView, targetFov, ref fovVelocity, fovSmoothTime);
        }

        float ComputeAllowedDistance(Vector3 origin, Vector3 direction, float maxDistance)
        {
            int count = Physics.SphereCastNonAlloc(origin, collisionRadius, direction, hits,
                                                   maxDistance, collisionMask, QueryTriggerInteraction.Ignore);
            float nearest = maxDistance;
            for (int i = 0; i < count; i++)
            {
                if (hits[i].transform.IsChildOf(target)) continue; // ignore the player's own colliders
                if (hits[i].distance < nearest) nearest = hits[i].distance;
            }
            return Mathf.Max(nearest, minDistance);
        }

        void HandleCursor()
        {
            if (!lockCursor) return;
            Keyboard kb = Keyboard.current;
            Mouse mouse = Mouse.current;

            if (kb != null && kb.escapeKey.wasPressedThisFrame) SetCursor(false);
            else if (Cursor.lockState != CursorLockMode.Locked && mouse != null && mouse.leftButton.wasPressedThisFrame)
                SetCursor(true);
        }

        static void SetCursor(bool locked)
        {
            Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !locked;
        }
    }
}
