using UnityEngine;

namespace NEXUS.Player
{
    /// <summary>
    /// Glue: reads local input, builds a MoveCommand, hands it to the motor.
    /// Phase 8 (multiplayer): only the owning client runs this; the command is also sent to the server,
    /// which re-simulates it authoritatively and reconciles the client.
    /// </summary>
    [RequireComponent(typeof(PlayerInputReader))]
    [RequireComponent(typeof(PlayerMotor))]
    [DisallowMultipleComponent]
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] ThirdPersonCamera cameraRig;

        PlayerInputReader input;
        PlayerMotor motor;

        void Awake()
        {
            input = GetComponent<PlayerInputReader>();
            motor = GetComponent<PlayerMotor>();
        }

        void Update()
        {
            var cmd = new MoveCommand
            {
                Move = input.Move,
                Yaw = cameraRig != null ? cameraRig.Yaw : transform.eulerAngles.y,
                Sprint = input.SprintHeld,
                Jump = input.JumpPressed,
                CrouchToggle = input.CrouchPressed,
                Aiming = input.AimHeld
            };

            motor.Simulate(cmd, Time.deltaTime);
        }
    }
}
