using UnityEngine;
using UnityEngine.InputSystem;

namespace NEXUS.Player
{
    /// <summary>
    /// Wraps Unity Input System actions (created in code, so no .inputactions asset is required).
    /// Keyboard/mouse + gamepad. Mobile touch controls will feed the same properties in a later phase.
    /// Key remapping (later) should replace the hard-coded bindings below.
    /// </summary>
    [DisallowMultipleComponent]
    public class PlayerInputReader : MonoBehaviour
    {
        [Header("Look")]
        [SerializeField] float mouseSensitivity = 0.08f;   // degrees per pixel of mouse delta
        [SerializeField] float gamepadSensitivity = 140f;  // degrees per second at full stick
        [SerializeField] bool invertY;

        InputAction move, lookMouse, lookPad, sprint, jump, crouch, aim, fire, switchShoulder;

        public Vector2 Move => move != null ? move.ReadValue<Vector2>() : Vector2.zero;
        public bool SprintHeld => sprint != null && sprint.IsPressed();
        public bool AimHeld => aim != null && aim.IsPressed();
        public bool FireHeld => fire != null && fire.IsPressed();
        public bool JumpPressed => jump != null && jump.WasPressedThisFrame();
        public bool CrouchPressed => crouch != null && crouch.WasPressedThisFrame();
        public bool SwitchShoulderPressed => switchShoulder != null && switchShoulder.WasPressedThisFrame();

        /// <summary>Look delta in degrees for this frame: x = yaw, y = pitch (positive = look up).</summary>
        public Vector2 ReadLook(float deltaTime)
        {
            Vector2 mouse = lookMouse.ReadValue<Vector2>() * mouseSensitivity;
            Vector2 pad = lookPad.ReadValue<Vector2>() * (gamepadSensitivity * deltaTime);
            Vector2 look = mouse + pad;
            if (invertY) look.y = -look.y;
            return look;
        }

        void Awake()
        {
            move = new InputAction("Move", InputActionType.Value);
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/w").With("Down", "<Keyboard>/s")
                .With("Left", "<Keyboard>/a").With("Right", "<Keyboard>/d");
            move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/upArrow").With("Down", "<Keyboard>/downArrow")
                .With("Left", "<Keyboard>/leftArrow").With("Right", "<Keyboard>/rightArrow");
            move.AddBinding("<Gamepad>/leftStick");

            lookMouse = new InputAction("LookMouse", InputActionType.Value, "<Mouse>/delta");
            lookPad = new InputAction("LookPad", InputActionType.Value, "<Gamepad>/rightStick");

            sprint = Button("Sprint", "<Keyboard>/leftShift", "<Gamepad>/leftStickPress");
            jump = Button("Jump", "<Keyboard>/space", "<Gamepad>/buttonSouth");
            crouch = Button("Crouch", "<Keyboard>/c", "<Keyboard>/leftCtrl", "<Gamepad>/buttonEast");
            aim = Button("Aim", "<Mouse>/rightButton", "<Gamepad>/leftTrigger");
            fire = Button("Fire", "<Mouse>/leftButton", "<Gamepad>/rightTrigger");
            switchShoulder = Button("SwitchShoulder", "<Keyboard>/v", "<Gamepad>/dpad/right");
        }

        static InputAction Button(string name, params string[] bindings)
        {
            var action = new InputAction(name, InputActionType.Button);
            foreach (string b in bindings) action.AddBinding(b);
            return action;
        }

        void OnEnable() { foreach (var a in All()) a.Enable(); }
        void OnDisable() { foreach (var a in All()) a.Disable(); }

        void OnDestroy() { foreach (var a in All()) a.Dispose(); }

        InputAction[] All() => new[] { move, lookMouse, lookPad, sprint, jump, crouch, aim, fire, switchShoulder };
    }
}
