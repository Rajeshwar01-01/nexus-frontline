#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using NEXUS.Core;
using NEXUS.Player;

namespace NEXUS.EditorTools
{
    /// <summary>
    /// NEXUS > Phase 1 > Build Test Scene
    /// Adds a ground, stairs, ramp, wall, a low tunnel (crouch/slide test), a GameManager, a primitive-capsule
    /// player and the camera rig to the CURRENT scene. Primitives are placeholders only (see design doc, section 55).
    /// </summary>
    public static class Phase1TestSceneBuilder
    {
        [MenuItem("NEXUS/Phase 1/Build Test Scene")]
        static void Build()
        {
            var root = new GameObject("TestArena");
            Undo.RegisterCreatedObjectUndo(root, "Build NEXUS test scene");

            // Ground
            Block(root, "Ground", new Vector3(0, -0.5f, 0), new Vector3(120, 1, 120));

            // Stairs (step height 0.25 < controller stepOffset)
            for (int i = 0; i < 8; i++)
            {
                float h = (i + 1) * 0.25f; // each block is a full-height column, so every step rises 0.25m
                Block(root, "Stair" + i, new Vector3(6, h * 0.5f, 4 + i * 0.6f), new Vector3(4, h, 0.6f));
            }

            // Ramp
            var ramp = Block(root, "Ramp", new Vector3(-6, 0.9f, 6), new Vector3(4, 0.3f, 8));
            ramp.transform.rotation = Quaternion.Euler(-20f, 0f, 0f);

            // Wall (future vault/mantle test) and tall wall (camera collision test)
            Block(root, "LowWall", new Vector3(0, 0.5f, 10), new Vector3(6, 1f, 0.4f));
            Block(root, "TallWall", new Vector3(-12, 2f, 0), new Vector3(0.5f, 4f, 10));

            // Low tunnel: bottom of slab at 1.3m -> crouch (1.1m) and slide (1.0m) fit, standing (1.8m) does not
            Block(root, "TunnelPillarL", new Vector3(10, 0.75f, -6), new Vector3(0.5f, 1.5f, 6));
            Block(root, "TunnelPillarR", new Vector3(14, 0.75f, -6), new Vector3(0.5f, 1.5f, 6));
            Block(root, "TunnelRoof", new Vector3(12, 1.55f, -6), new Vector3(4.5f, 0.5f, 6));

            // Light
            if (Object.FindFirstObjectByType<Light>() == null)
            {
                var lightGo = new GameObject("Directional Light");
                var light = lightGo.AddComponent<Light>();
                light.type = LightType.Directional;
                lightGo.transform.rotation = Quaternion.Euler(50, -30, 0);
                Undo.RegisterCreatedObjectUndo(lightGo, "Light");
            }

            // GameManager
            if (Object.FindFirstObjectByType<GameManager>() == null)
            {
                var gm = new GameObject("GameManager");
                gm.AddComponent<GameManager>();
                Undo.RegisterCreatedObjectUndo(gm, "GameManager");
            }

            // Player
            var player = new GameObject("Player");
            player.transform.position = new Vector3(0, 0.1f, -4);
            var cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.4f;
            cc.center = new Vector3(0, 0.9f, 0);
            cc.stepOffset = 0.35f;
            cc.slopeLimit = 50f;
            player.AddComponent<PlayerInputReader>();
            var motor = player.AddComponent<PlayerMotor>();
            var controller = player.AddComponent<PlayerController>();
            Undo.RegisterCreatedObjectUndo(player, "Player");

            // Placeholder visual (primitive capsule, collider removed - the CharacterController is the collider)
            var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            visual.name = "Visual";
            Object.DestroyImmediate(visual.GetComponent<Collider>());
            visual.transform.SetParent(player.transform, false);
            visual.transform.localPosition = new Vector3(0, 0.9f, 0);
            visual.transform.localScale = new Vector3(0.8f, 0.9f, 0.8f);

            // Facing marker so you can see which way the character points
            var nose = GameObject.CreatePrimitive(PrimitiveType.Cube);
            nose.name = "FacingMarker";
            Object.DestroyImmediate(nose.GetComponent<Collider>());
            nose.transform.SetParent(player.transform, false);
            nose.transform.localPosition = new Vector3(0, 1.4f, 0.4f);
            nose.transform.localScale = new Vector3(0.25f, 0.15f, 0.3f);

            // Camera
            Camera cam = Camera.main;
            if (cam == null)
            {
                var camGo = new GameObject("Main Camera");
                camGo.tag = "MainCamera";
                cam = camGo.AddComponent<Camera>();
                camGo.AddComponent<AudioListener>();
                Undo.RegisterCreatedObjectUndo(camGo, "Camera");
            }
            var rig = cam.GetComponent<ThirdPersonCamera>();
            if (rig == null) rig = Undo.AddComponent<ThirdPersonCamera>(cam.gameObject);

            // Wire serialized references
            var motorSo = new SerializedObject(motor);
            motorSo.FindProperty("visualRoot").objectReferenceValue = visual.transform;
            motorSo.ApplyModifiedPropertiesWithoutUndo();

            var camSo = new SerializedObject(rig);
            camSo.FindProperty("target").objectReferenceValue = player.transform;
            camSo.ApplyModifiedPropertiesWithoutUndo();

            var ctrlSo = new SerializedObject(controller);
            ctrlSo.FindProperty("cameraRig").objectReferenceValue = rig;
            ctrlSo.ApplyModifiedPropertiesWithoutUndo();

            Selection.activeGameObject = player;
            Debug.Log("[NEXUS] Phase 1 test arena built. Press Play. WASD move, Shift sprint, Space jump, C/Ctrl crouch, " +
                      "Shift+C slide, RMB aim, V swap shoulder, Esc free cursor.");
        }

        static GameObject Block(GameObject parent, string name, Vector3 position, Vector3 scale)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent.transform, false);
            go.transform.position = position;
            go.transform.localScale = scale;
            return go;
        }
    }
}
#endif
