using System;
using UnityEngine;

namespace NEXUS.Core
{
    /// <summary>High-level game flow states (matches the startup flow in the design doc).</summary>
    public enum GameState { Boot, Login, Lobby, Training, InMatch, Results }

    /// <summary>
    /// Lightweight static event bus. Systems publish here instead of referencing each other directly.
    /// Subscribers MUST unsubscribe in OnDisable/OnDestroy.
    /// </summary>
    public static class GameEvents
    {
        public static event Action<GameState, GameState> StateChanged;
        public static event Action PlayerJumped;
        /// <summary>Argument = impact speed in m/s (use later for fall damage / landing VFX).</summary>
        public static event Action<float> PlayerLanded;
        public static event Action<bool> PlayerSlideChanged;
        public static event Action<bool> PlayerCrouchChanged;

        public static void RaiseStateChanged(GameState from, GameState to) => StateChanged?.Invoke(from, to);
        public static void RaisePlayerJumped() => PlayerJumped?.Invoke();
        public static void RaisePlayerLanded(float impactSpeed) => PlayerLanded?.Invoke(impactSpeed);
        public static void RaisePlayerSlideChanged(bool sliding) => PlayerSlideChanged?.Invoke(sliding);
        public static void RaisePlayerCrouchChanged(bool crouching) => PlayerCrouchChanged?.Invoke(crouching);

        // Static events survive when "Enter Play Mode" skips domain reload, so clear them on startup.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            StateChanged = null;
            PlayerJumped = null;
            PlayerLanded = null;
            PlayerSlideChanged = null;
            PlayerCrouchChanged = null;
        }
    }
}
