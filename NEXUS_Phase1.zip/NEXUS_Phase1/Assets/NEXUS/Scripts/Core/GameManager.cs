using UnityEngine;

namespace NEXUS.Core
{
    /// <summary>
    /// Persistent game-flow owner. Phase 1: holds the current GameState and applies frame-rate settings.
    /// Later phases: scene flow (Boot > Login > Lobby > Match), hooking into Backend/Network managers.
    /// </summary>
    [DisallowMultipleComponent]
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [SerializeField] int targetFrameRate = 60;
        [SerializeField] GameState startState = GameState.Training;

        public GameState State { get; private set; } = GameState.Boot;

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);

            // VSync must be off for targetFrameRate to apply.
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = targetFrameRate;
        }

        void Start() => SetState(startState);

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void SetState(GameState next)
        {
            if (next == State) return;
            GameState previous = State;
            State = next;
            GameEvents.RaiseStateChanged(previous, next);
        }
    }
}
